package modelo;

/**
 *@author Flávio
 *Importação das bibliotecas para a conexão com o banco de dados
 */
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class ConversaDAO extends DataBaseDAO{

    public ConversaDAO() throws Exception {}   

    public void Cadastrar(Conversa conversa) throws Exception {
        PreparedStatement pst;
        String sql = "INSERT INTO conversa (ID,Mensagem,Imagem_Arquivo,Usuario_Login) VALUES(?,?,?,?)";
        pst = conn.prepareStatement(sql);
        pst.setInt(1, conversa.getId());
        pst.setString(2, conversa.getMensagem());
        pst.setBytes(3, conversa.getImagemArquivo());
        pst.setString(4, conversa.usuario.getLogin());
        pst.execute();
    } 

    public void Alterar(Conversa conversa) throws Exception {
        PreparedStatement pst;
        String sql = "UPDATE conversa SET Mensagem=?,Imagem_Arquivo=? WHERE ID=?";
        pst = conn.prepareStatement(sql);        
        pst.setString(1, conversa.getMensagem());
        pst.setBytes(2, conversa.getImagemArquivo());
        pst.setInt(3, conversa.getId());
        
        pst.execute();
    }

    public void excluir(Conversa conversa) throws Exception {
        PreparedStatement pst;
        String sql = "DELETE FROM conversa WHERE id=?";
        pst = conn.prepareStatement(sql);
        pst.setInt(1, conversa.getId());
        pst.execute();
    } 

    public ArrayList<Conversa> listar() throws Exception {
        ArrayList<Conversa> lista = new ArrayList<Conversa>();
        PreparedStatement pst;
        ResultSet rs;
        String sql = "SELECT * FROM conversa WHERE Usuario_Login=?";
        pst = conn.prepareStatement(sql);
        rs = pst.executeQuery();
        while (rs.next()) {
            Conversa C = new Conversa();
            Usuario usuario = new Usuario();
            pst.setString(1, C.usuario.getLogin());
            C.setId(rs.getInt("ID"));
            C.setMensagem(rs.getString("Mensagem"));
            C.setImagemArquivo(rs.getBytes("Imagem_arquivo"));
            C.setUsuario(usuario);
            lista.add(C);
        }

        return lista;
    }
    
}
